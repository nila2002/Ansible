$ws = New-Object -ComObject Wscript.Shell
$ws.Popup("This example script ran successfully.", 0, "Info", 0x40)